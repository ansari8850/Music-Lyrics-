package com.example.music_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
